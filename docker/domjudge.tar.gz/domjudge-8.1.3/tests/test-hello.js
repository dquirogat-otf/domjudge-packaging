// This should give CORRECT on the default problem 'hello'.
//
// @EXPECTED_RESULTS@: CORRECT

console.log('Hello world!');
