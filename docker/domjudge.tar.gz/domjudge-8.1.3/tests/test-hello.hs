{-
 - This should give CORRECT on the default problem 'hello'.
 -
 - @EXPECTED_RESULTS@: CORRECT
 -}

import System.IO
main = do	putStr "Hello world!\n"
