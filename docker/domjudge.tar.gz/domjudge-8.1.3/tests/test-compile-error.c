/*
 * This should fail with a COMPILER-ERROR
 *
 * @EXPECTED_RESULTS@: COMPILER-ERROR
 */

#include <stdio.h>

This is not correct C-syntax and will give compilation errors!
