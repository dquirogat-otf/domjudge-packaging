#include <unistd.h>

int main() {
  while (1) {
    sleep(1000);
  }
}
